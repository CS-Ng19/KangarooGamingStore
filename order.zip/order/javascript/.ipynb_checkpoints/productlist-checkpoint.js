/* ===== 1/* ===== 2. 商品資料 ================================================= */
const products = {
    base: {
        display: "Hypixel Rank",
        limit: 1,
        variants: { "VIP": 56, "VIP+": 128, "MVP": 265, "MVP+": 368.5 }
    },
    vipUp: {
        display: "[VIP] 升級 Hypixel Rank",
        limit: 1,
        variants: { "VIP+": 128, "MVP": 265, "MVP+": 368.5 }
    },
    addon: {
        display: "以優惠價加配",
        limit: 3,
        variants: {
            "全新Optifine 披風": 79,
            "Minecraft PC&Win10兌換碼": 142
        }
    }
};
