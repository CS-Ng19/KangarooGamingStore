/* ===== 1. 連結 URL ================================================= */
const scriptURL = "https://script.google.com/macros/s/AKfycbzr8q_6qQs7NdcasLLM6_9IBFRS5H3ouZ3zh12Ehy80F2NR3zlbxJivqPtLzao8oe0tjw/exec";
const discordWebhookURL = "https://discordapp.com/api/webhooks/1370329424968552550/JPUnSGXpOdOdjOYqT2bWy8T8yr3DAYba520bOJmdeBRHOO1LNJSYR01Qcbch413ocj8g";